const LocalStrategy  = require('passport-local').Strategy;
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const username='';
// Load user model
const userdetails = mongoose.model('userdetails');

module.exports = function(passport){
  passport.use(new LocalStrategy({usernameField: 'name'}, (name, password, done) => {
    // Match user
    userdetails.findOne({
      name:name
    }).then(userdetails => {
      if(!userdetails){
        return done(null, false, {message: 'No User Found'});
      } 

      // Match password
      bcrypt.compare(password, userdetails.password, (err, isMatch) => {
        if(err) throw err;
        if(isMatch){

          return done(null, userdetails);
        } else {
          return done(null, false, {message: 'Password Incorrect'});
        }
      })
    })
  }));

  passport.serializeUser(function(userdetails, done) {
    done(null, userdetails.name);
  });
  
  passport.deserializeUser(function(id, done) {
    User.findById(id, function(err, userdetails) {
      done(err, userdetails);
    });
  });
}