
const exphbs  = require('express-handlebars');
const flash = require('connect-flash');
const session = require('express-session');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt=require('bcryptjs');
const passport=require('passport');
const fs=require('fs');

const app = require('express')();
const server = require('http').Server(app);
const io = require('socket.io')(server);
const port = 6000;
var user;


server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});

app.get('/cc', (req, res) => {
    
    res.sendFile(__dirname + '/public/index.html');
});

app.get('/india',(req, res) => {
    
    console.log(user);

    res.render(__dirname + '/public/india',{'user':user});
});

app.get('/dubai', (req, res) => {
    res.render(__dirname + '/public/dubai',{'user':user});
});

app.get('/uk', (req, res) => {
    res.render(__dirname + '/public/uk',{'user':user});
});

// tech namespace
const tech = io.of('/tech');
const msg="";

tech.on('connection', (socket) => {
    socket.on('join', (data) => {
        socket.join(data.room);
        tech.in(data.room).emit('message', `New User  ${user} joined ${data.room} room!`);
    })

    socket.on('message', (data) => {
        console.log(`message: ${data.msg}`);
        tech.in(data.room).emit('message', data.msg);
    });

    socket.on('disconnect', () => {const msg= user +"disconnected";
        console.log(msg);

        tech.emit('message', msg);
    })
})
//-----------------------------------------------------------------------------------
// Map global promise - get rid of warning
mongoose.Promise = global.Promise;
// Connect to mongoose
mongoose.connect('mongodb://localhost/chatdb', {
    useNewUrlParser: true 
})
  .then(() => console.log('MongoDB Connected...'))
  .catch(err => console.log(err));
// Load Idea Model
require('./models/Userlog');
const userdetails = mongoose.model('userdetails');

// Passport Config
require('./config/passport')(passport);
app.use(passport.initialize());
app.use(passport.session());

// Handlebars Middleware  
app.engine('handlebars', exphbs({
  defaultLayout: 'main'
}));
app.set('view engine', 'handlebars');

// Body parser middleware
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

// Express session midleware
app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: true
  }));
  
  app.use(flash());
  
  // Global variables
  app.use(function(req, res, next){
    res.locals.success_msg = req.flash('success_msg');
    res.locals.error_msg = req.flash('error_msg');
    res.locals.error = req.flash('error');
    res.locals.user;
    next();
  });
  
// Index Route
app.get('/', (req, res) => {
  const title = 'Welcome';
  
  res.render('index', {

  });
});

// About Route
app.get('/about', (req, res) => {


  res.render('about');
});

// About Login
app.get('/Login', (req, res) => {
    res.render('Login');
  });
  app.get('/chat', (req, res) => {
    res.render('chat');
  });
// Process Form
app.post('/Reg', (req, res) => {
    let errors = [];
   
   
    if(!req.body.first_name){
      errors.push({text:'Please enter your name'});
    }
    if(!req.body.email){
      errors.push({text:'Please enter your email'});
    }
    
    if(!req.body.password){
        errors.push({text:'Please enter your password'});
      }
      if(!req.body.password_confirmation){
        errors.push({text:'Please enter same password'});
      }
     
  
    if(errors.length > 0){
      res.render('index', {
        errors: errors,
        title: req.body.title,
        details: req.body.details
      });
    } else {
        const newUser = {
            name: req.body.first_name,
            email: req.body.email,
            password:req.body.password
          }
          bcrypt.genSalt(10, (err, salt) => {
            bcrypt.hash(newUser.password, salt, (err, hash) => {
              if(err) throw err;
              newUser.password = hash;
              new userdetails(newUser).save()
                .then(userdetails => {
                  req.flash('succes_msg', 'You are now registered and can log in');
                  res.redirect('login');
                })
                .catch(err => {
                  console.log(err);
                  return;
                });
            });
          });
        }
       //   new userdetails(newUser)
       //     .save();
        //                  res.render('Login');
        

    
  });
  // About Route
app.post('/log', (req, res,next) => {
    
user=req.body.name;
console.log(user);
    passport.authenticate('local', {
        successRedirect:'chat' ,
        failureRedirect: '/',
        failureFlash: true,

      })(req, res, next);

      
    
  });
 
  